﻿Function showMenu
{
    Write-Host -ForegroundColor Cyan "Select a task";
    Write-Host -ForegroundColor Cyan "================================";
    Write-Host -ForegroundColor Cyan "1 - Restart DameWare v9 service";
    Write-Host -ForegroundColor Cyan "2 - Restart Printer Spooler";
    Write-Host -ForegroundColor Cyan "3 - Restart $computerName";
    Write-Host -ForegroundColor Cyan "4 - Get System Uptime";
    Write-Host -ForegroundColor Cyan "5 - Get disk space";
    Write-Host -ForegroundColor Cyan "6 - Current login users";
    Write-Host -ForegroundColor Cyan "7 - Get monitor info";
    Write-Host -ForegroundColor Cyan "8 - Last 7 Stability Index";
    Write-Host -ForegroundColor Cyan "9 - Get virus definition";
    Write-Host -ForegroundColor Cyan "10 - Add user to local admin"; 
    Write-Host -ForegroundColor Cyan "11 - Get hotfix installed"; 
    Write-Host -ForegroundColor Cyan "12 - Kill task"; 
    Write-Host -ForegroundColor Cyan "C - Change host";
    Write-Host -ForegroundColor Cyan "Q - Quit";
    parseMainSelection(Read-Host -Prompt "Please make your selection");


}

Function parseMainSelection($selection)
{
   switch ($selection) 
    { 
        1 {restartService("DWMRCS")
          } 
        2 {restartService("Spooler")
          
          } 
        3 {write-host ((Restart-Computer -ComputerName $computerName -AsJob -Force -Confirm))} 
        4 {Get-Uptime
            showMenu ;
            } 
        5 {Get-DiskFree -ComputerName $computerName -Format;
                showMenu;
            } 
        6 {Get-WMIComputerSessions -computer $computerName;
                showMenu;
           } 
        7 {
            Get-MonitorInfo -ComputerName $computerName;
            #NvidiaWMI;
            showMenu;
          }
        8 {StabilityIndex;
            showMenu;    
          }
        9{getSEPDef;
            showMenu;
        }
        10{$username=Read-Host -Prompt "Please input the username name";
        Add-DomainUserToLocalGroup -computer $computerName -group Administrators -domain $env:USERDOMAIN -user $username -Verbose;
        showMenu;
        }
        11{
        get-hotfixInstalled;
        showMenu;
        }
        12{
            Killtask;        
        }
        M{
            showMenu;
        }
        
        C {Main;
          }
        Q {Exit} 
        default {Write-Host -ForegroundColor Red "Invalid selection.";
                   showMenu ;
                   }
    }
 


}

Function parseTaskSelection($selection)
{
   switch ($selection) 
    { 
        
        M{
            showMenu;
        }
        K{
            EndProcess("kix32.exe");
            showMenu;
        }
        E{
            EndProcess("explorer.exe");
            showMenu;
        }
        I{
            EndProcess("iexplore.exe");
            showMenu;
        }
        A{
            Get-WmiObject win32_process -ComputerName $ComputerName|select-object ProcessName,Path|sort ProcessName|Out-GridView;
            EndProcess(Read-Host -Prompt "Please input the process name");
            showMenu;
          }
        C {Main;
          }
        Q {Exit} 
        default {Write-Host -ForegroundColor Red "Invalid selection.";
                   showMenu ;
                   }
    }
 


}

#https://4sysops.com/archives/calculating-system-uptime-with-powershell/
Function Get-Uptime {
   $os = Get-WmiObject win32_operatingsystem -ComputerName $computerName
   $uptime = (Get-Date) - ($os.ConvertToDateTime($os.lastbootuptime))
   $Display = "Uptime: " + $Uptime.Days + " days, " + $Uptime.Hours + " hours, " + $Uptime.Minutes + " minutes" 
   Write-Output $Display
   showMenu
}


Function restartService($serviceName)
{
    $service = Get-service -ComputerName $computerName -Name $serviceName;
    $service;

    Restart-Service -Force -InputObject $service -Verbose;
    $service.Refresh();
    $service;
    showMenu;
}


#http://binarynature.blogspot.hk/2010/04/powershell-version-of-df-command.html
function Get-DiskFree
{
    [CmdletBinding()]
    param 
    (
        [Parameter(Position=0,
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [Alias('hostname')]
        [Alias('cn')]
        [string[]]$ComputerName = $env:COMPUTERNAME,
        
        [Parameter(Position=1,
                   Mandatory=$false)]
        [Alias('runas')]
        [System.Management.Automation.Credential()]$Credential =
        [System.Management.Automation.PSCredential]::Empty,
        
        [Parameter(Position=2)]
        [switch]$Format
    )
    
    BEGIN
    {
        function Format-HumanReadable 
        {
            param ($size)
            switch ($size) 
            {
                {$_ -ge 1PB}{"{0:#.#'P'}" -f ($size / 1PB); break}
                {$_ -ge 1TB}{"{0:#.#'T'}" -f ($size / 1TB); break}
                {$_ -ge 1GB}{"{0:#.#'G'}" -f ($size / 1GB); break}
                {$_ -ge 1MB}{"{0:#.#'M'}" -f ($size / 1MB); break}
                {$_ -ge 1KB}{"{0:#'K'}" -f ($size / 1KB); break}
                default {"{0}" -f ($size) + "B"}
            }
        }
        
        $wmiq = 'SELECT * FROM Win32_LogicalDisk WHERE Size != Null AND DriveType >= 2'
    }
    
    PROCESS
    {
        foreach ($computer in $ComputerName)
        {
            try
            {
                if ($computer -eq $env:COMPUTERNAME)
                {
                    $disks = Get-WmiObject -Query $wmiq `
                             -ComputerName $computer -ErrorAction Stop
                }
                else
                {
                    $disks = Get-WmiObject -Query $wmiq `
                             -ComputerName $computer -Credential $Credential `
                             -ErrorAction Stop
                }
                
                if ($Format)
                {
                    # Create array for $disk objects and then populate
                    $diskarray = @()
                    $disks | ForEach-Object { $diskarray += $_ }
                    
                    $diskarray | Select-Object @{n='Name';e={$_.SystemName}}, 
                        @{n='Vol';e={$_.DeviceID}},
                        @{n='Size';e={Format-HumanReadable $_.Size}},
                        @{n='Used';e={Format-HumanReadable `
                        (($_.Size)-($_.FreeSpace))}},
                        @{n='Avail';e={Format-HumanReadable $_.FreeSpace}},
                        @{n='Use%';e={[int](((($_.Size)-($_.FreeSpace))`
                        /($_.Size) * 100))}},
                        @{n='FS';e={$_.FileSystem}},
                        @{n='Type';e={$_.Description}}
                }
                else 
                {
                    foreach ($disk in $disks)
                    {
                        $diskprops = @{'Volume'=$disk.DeviceID;
                                   'Size'=$disk.Size;
                                   'Used'=($disk.Size - $disk.FreeSpace);
                                   'Available'=$disk.FreeSpace;
                                   'FileSystem'=$disk.FileSystem;
                                   'Type'=$disk.Description;                                  
                                   'Computer'=$disk.SystemName;}
                    
                        # Create custom PS object and apply type
                        $diskobj = New-Object -TypeName PSObject `
                                   -Property $diskprops
                        $diskobj.PSObject.TypeNames.Insert(0,'BinaryNature.DiskFree')
                    
                        Write-Output $diskobj
                    }
                }
            }
            catch 
            {
                # Check for common DCOM errors and display "friendly" output
                switch ($_)
                {
                    { $_.Exception.ErrorCode -eq 0x800706ba } `
                        { $err = 'Unavailable (Host Offline or Firewall)'; 
                            break; }
                    { $_.CategoryInfo.Reason -eq 'UnauthorizedAccessException' } `
                        { $err = 'Access denied (Check User Permissions)'; 
                            break; }
                    default { $err = $_.Exception.Message }
                }
                Write-Warning "$computer - $err"
            } 
        }
    }
    
    END {}
}


#http://learn-powershell.net/2010/11/01/quick-hit-find-currently-logged-on-users/
Function Get-WMIComputerSessions {
<#
.SYNOPSIS
    Retrieves all user sessions from local or remote server/s
.DESCRIPTION
    Retrieves all user sessions from local or remote server/s
.PARAMETER computer
    Name of computer/s to run session query against.
.NOTES
    Name: Get-WmiComputerSessions
    Author: Boe Prox
    DateCreated: 01Nov2010
 
.LINK
    https://boeprox.wordpress.org
.EXAMPLE
Get-WmiComputerSessions -computer "server1"
 
Description
-----------
This command will query all current user sessions on 'server1'.
 
#>
[cmdletbinding(
    DefaultParameterSetName = 'session',
    ConfirmImpact = 'low'
)]
    Param(
        [Parameter(
            Mandatory = $True,
            Position = 0,
            ValueFromPipeline = $True)]
            [string[]]$computer
    )
Begin {
    #Create empty report
    $report = @()
    }
Process {
    #Iterate through collection of computers
    ForEach ($c in $computer) {
        #Get explorer.exe processes
        $proc = gwmi win32_process -computer $c -Filter "Name = 'explorer.exe'"
        #Go through collection of processes
        ForEach ($p in $proc) {
            $temp = "" | Select Computer, Domain, User
            $temp.computer = $c
            $temp.user = ($p.GetOwner()).User
            $temp.domain = ($p.GetOwner()).Domain
            $report += $temp
          }
        }
    }
End {
    $report
    }
}


#http://www.hofferle.com/updated-get-monitorinfo/
Function Get-MonitorInfo
{

    
    [CmdletBinding()]
    Param
    (
        [Parameter(
        Position=0,
        ValueFromPipeLine=$true,
        ValueFromPipeLineByPropertyName=$true)]
        [alias("CN","MachineName","Name","Computer")]
        [string[]]$ComputerName = $ENV:ComputerName
    )

    Begin {
        $pipelineInput = -not $PSBoundParameters.ContainsKey('ComputerName')
    }

    Process
    {
        Function DoWork([string]$ComputerName) {
            $ActiveMonitors = Get-WmiObject -Namespace root\wmi -Class wmiMonitorID -ComputerName $ComputerName
            $monitorInfo = @()

            foreach ($monitor in $ActiveMonitors)
            {
                $mon = $null

                $mon = New-Object PSObject -Property @{
                ManufacturerName=($monitor.ManufacturerName | % {[char]$_}) -join ''
                ProductCodeID=($monitor.ProductCodeID | % {[char]$_}) -join ''
                SerialNumberID=($monitor.SerialNumberID | % {[char]$_}) -join ''
                UserFriendlyName=($monitor.UserFriendlyName | % {[char]$_}) -join ''
                ComputerName=$ComputerName
                WeekOfManufacture=$monitor.WeekOfManufacture
                YearOfManufacture=$monitor.YearOfManufacture}

                $monitorInfo += $mon
            }
            Write-Output $monitorInfo
        }

        if ($pipelineInput) {
            DoWork($ComputerName)
        } else {
            foreach ($item in $ComputerName) {
                DoWork($item)
            }
        }
    }
}

Function EndProcess($ProcessName)
{
    
(Get-WmiObject win32_process -ComputerName $ComputerName -Filter "name='$ProcessName'").Terminate();
}


Function StabilityIndex
{


get-wmiobject Win32_ReliabilityStabilityMetrics -computername $computerName -property "SystemStabilityIndex" | 
  select-object -last 7 SystemStabilityIndex | format-table *

}


Function getSEPDef
{

    $virusdef= Get-Content "\\$computerName\c$\ProgramData\Symantec\Symantec Endpoint Protection\CurrentVersion\Data\Definitions\VirusDefs\definfo.dat" #-tail 1
    write-host $virusdef

}


#https://blogs.technet.microsoft.com/heyscriptingguy/2010/08/19/use-powershell-to-add-domain-users-to-a-local-group/
    Function Add-DomainUserToLocalGroup
    {
    [cmdletBinding()]
    Param(
    [Parameter(Mandatory=$True)]
    [string]$computer,
    [Parameter(Mandatory=$True)]
    [string]$group,
    [Parameter(Mandatory=$True)]
    [string]$domain,
    [Parameter(Mandatory=$True)]
    [string]$user
    )
    $de = [ADSI]“WinNT://$computer/$Group,group”
    $de.psbase.Invoke(“Add”,([ADSI]“WinNT://$domain/$user”).path)
    } #end function Add-DomainUserToLocalGroup

Function get-hotfixInstalled
{
    Get-HotFix -ComputerName $computerName|Out-GridView ;
    Write-host "`n`n The number of hotfix installed:"
    Write-host (Get-HotFix -ComputerName $computerName).count;
    
}

Function NvidiaWMI
{
    #write-host "Display Card"
    #write-host (gwmi win32_videocontroller -ComputerName $ComputerName|select-object -ExpandProperty name)
    $video_card_name=(gwmi win32_videocontroller -ComputerName $ComputerName)|select-object -Expand name
    
    If($supportedModels|?{$video_card_name -eq $_})
    {

    #Write-Host "True"
    gwmi -ComputerName $ComputerName -Namespace root\CIMV2\NV gpu|select-object name,percent*


    $namespace = "root\CIMV2\NV"
    $classname = "ThermalProbe"
    # For local system (e.g. "LocalHost", ".") '-computername $computer' could be omitted
    # retrieve all instances of the ThermalProbe class and store them:
    $probes =Get-WmiObject -class $classname -computername $ComputerName -namespace $namespace
    # print all ThermalProbe instances
    $probes
    # iterate through all Probe instances
    foreach( $probe in $probes )
    {
    #"Call the info() method and print all the data"
    $res = $probe.InvokeMethod("info",$Null)
    $res
    #"Query just the temperature"
    #$temp = $probe.temperature
    #$temp
    }
}



}


Function Killtask
{
    Write-Host -ForegroundColor Cyan "Select a task";
    Write-Host -ForegroundColor Cyan "================================";
    Write-Host -ForegroundColor Cyan "K - Kill kix32.exe";
    Write-Host -ForegroundColor Cyan "E - Kill explorer.exe";
    Write-Host -ForegroundColor Cyan "I - Kill iexplore.exe";
    Write-Host -ForegroundColor Cyan "A - Anything";
    Write-Host -ForegroundColor Cyan "M - Back to Main Menu";
    Write-Host -ForegroundColor Cyan "Q - Quit";
    parseTaskSelection(Read-Host -Prompt "Please make your select");
    

}

Function Main
{

$computerName = Read-Host -Prompt "Please input the computer name"
Write-Host "Checking PC connection:";
$hostIsOnline = Test-Connection -Quiet -ComputerName $computerName

If($hostIsOnline)
    {
        Write-Host -ForegroundColor Green "Computer is online";
        showMenu;
    }
else
    {
        Write-Host -ForegroundColor Red "Computer is offline";
        Main;
    }

}


Main;